<template>
  <scrollable-navigation />
</template>

<script></script>
